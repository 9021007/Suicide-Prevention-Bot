# Suicide-Prevention-Bot


IF YOU'RE HAVING ISSUES: Check our system status at https://spbot.freshstatus.io 

A Discord bot to prevent suicide. It works by taking a list of phrases, and it compares it against every message sent in the server. if the message includes the words or phrases, it reacts with an informational embed that directs users to local hotlines.


![screenshot](https://spbot.ml/sc3.png)
